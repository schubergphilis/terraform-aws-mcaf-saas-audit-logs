"""Current version of package compress_json."""
__version__ = "1.0.6"
